---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: P2P通道
  icon: me_p2p_tunnel
---

# P2P通道

见[P2P通道](../items-blocks-machines/p2p_tunnels.md)。